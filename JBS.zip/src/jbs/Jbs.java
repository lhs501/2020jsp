package jbs;

public class Jbs {
	private int jbsID;
	private String jbsTitle;
	private String userID;
	private String jbsDate;
	private String jbsContent;
	private int jbsAvailable;
	public int getJbsID() {
		return jbsID;
	}
	public void setJbsID(int jbsID) {
		this.jbsID = jbsID;
	}
	public String getJbsTitle() {
		return jbsTitle;
	}
	public void setJbsTitle(String jbsTitle) {
		this.jbsTitle = jbsTitle;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getJbsDate() {
		return jbsDate;
	}
	public void setJbsDate(String jbsDate) {
		this.jbsDate = jbsDate;
	}
	public String getJbsContent() {
		return jbsContent;
	}
	public void setJbsContent(String jbsContent) {
		this.jbsContent = jbsContent;
	}
	public int getJbsAvailable() {
		return jbsAvailable;
	}
	public void setJbsAvailable(int jbsAvailable) {
		this.jbsAvailable = jbsAvailable;
	}
}
